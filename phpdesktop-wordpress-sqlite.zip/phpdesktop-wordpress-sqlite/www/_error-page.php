<title>Page not found</title>
<h1>Page not found</h1>
<meta charset=utf-8>

The page you were looking for does not exist.<br><br>

This is an example error page that will be displayed
when there is a navigation error in the browser control.
See the "msie" &gt; "error_page" option in settings.json.
It is not necesserily a 404 error, this will also handle
a 500 error when running php-cgi.exe fails.<br><br>

Status code: {{status_code}}<br>
Navigate url: {{navigate_url}}<br><br>

<script>document.write("Testing document.write(): OK")</script>

<center>Copyright &copy; 2016 PHK Corporation. All rights reserved.</center>
